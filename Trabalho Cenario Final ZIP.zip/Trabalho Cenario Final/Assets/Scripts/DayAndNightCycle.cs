﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;


public class DayAndNightCycle : MonoBehaviour {

    public float rotateSpeed = 10f;

    public bool isDay;
    public bool isNight;

    public Material windowMaterial;

    private float timeOfDay;

    [Range(0f, 1f)]
    public float sunIntensity;

    private GameObject[] streetLights;
    private GameObject[] fireflies;
    private GameObject[] nightWindow;
    private GameObject[] smoke;

    public Light sunLight;

    public Text testText;

    // Use this for initialization
	void Start ()
    {
        streetLights = GameObject.FindGameObjectsWithTag("Street Light");
        fireflies = GameObject.FindGameObjectsWithTag("Fireflies");
        nightWindow = GameObject.FindGameObjectsWithTag("Night Window");
        smoke = GameObject.FindGameObjectsWithTag("Smoke");

    }
	
	// Update is called once per frame
	void Update ()
    {
        SunRotate();
        CompleteCycle();

        DisableEnableLights();
        LightIntensityDown();
    }

    void SunRotate()
    {
        transform.Rotate(Vector3.left * rotateSpeed * Time.deltaTime);
    }

    void CompleteCycle()
    {
        timeOfDay = UnityEditor.TransformUtils.GetInspectorRotation(gameObject.transform).x;

        if (timeOfDay > 0f)
        {
            isDay = true;
            isNight = false;
        }

        if (timeOfDay < 0f)
        {
            isDay = false;
            isNight = true;
        }

    }

    void DisableEnableLights()
    {
        if (isNight == true)
        {
            foreach(GameObject go in streetLights)
                go.SetActive(true);
            foreach (GameObject go in fireflies)
                go.SetActive(true);
            foreach (GameObject go in nightWindow)
                go.SetActive(true);
            foreach (GameObject go in smoke)
                go.SetActive(true);

        }


        if (isNight == false)
        {
            foreach (GameObject go in streetLights)
                go.SetActive(false);
            foreach (GameObject go in fireflies)
                go.SetActive(false);
            foreach (GameObject go in nightWindow)
                go.SetActive(false);
            foreach (GameObject go in smoke)
                go.SetActive(false);
        }

        
    }

    void LightIntensityDown()
    {
        if (isDay == true && sunLight.intensity < 1)
        {
            sunLight.intensity += ++sunLight.intensity * Time.deltaTime / 5;
        }

        if (isNight == true && sunLight.intensity > 0)
        {
            sunLight.intensity -= sunLight.intensity * Time.deltaTime;
        }
    }



}
