﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ArrayExample : MonoBehaviour {

    private GameObject[] pointLights;
    
    // Use this for initialization
	void Start ()
    {
        pointLights = GameObject.FindGameObjectsWithTag("Street Light");
        Debug.Log(pointLights.Length);
        
	}
	
	// Update is called once per frame
	void Update () {
		
	}

    public void OnlyStreetLights()
    {
        //if(pointLights.tag)
    }
}
