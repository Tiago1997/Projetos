﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LightIntesityMeter : MonoBehaviour {

    public float min = 1;
    public float max = -1;

    public float lerpPerc = 0.5f;

    public Light sunLight;
    
    // Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update ()
    {
        sunLight.intensity = Mathf.Lerp(min, max, lerpPerc) * -transform.rotation.x * 20;
	}
}
